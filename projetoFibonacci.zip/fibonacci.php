<?php
// Função Fibonacci em PHP
function calcularFibonacci($n) {
    $a = 0;
    $b = 1;
    for ($i = 0; $i < $n; $i++) {
        $temp = $a;
        $a = $b;
        $b = $temp + $b;
    }
    return number_format($a); 
}

// Função Fatorial em PHP
function calcularFatorial($n) {
    $fatorial = 1;
    for ($i = 2; $i <= $n; $i++) {
        $fatorial *= $i;
    }
    return number_format($fatorial);
}

// Função para gerar matriz aleatória
function gerarMatrizAleatoria($tamanho) {
    $matriz = [];
    for ($i = 0; $i < $tamanho; $i++) {
        $matriz[$i] = [];
        for ($j = 0; $j < $tamanho; $j++) {
            $matriz[$i][$j] = rand(0, 99); 
        }
    }
    return $matriz;
}

// Função para Soma de Matrizes em PHP
function somarMatrizes($a, $b) {
    $resultado = [];
    for ($i = 0; $i < count($a); $i++) {
        for ($j = 0; $j < count($a[$i]); $j++) {
            $resultado[$i][$j] = number_format($a[$i][$j] + $b[$i][$j]);  // Formata o resultado
        }
    }
    return $resultado;
}

// Função para gerar sistema linear aleatório
function gerarSistemaLinearAleatorio($tamanho) {
    $sistema = [];
    for ($i = 0; $i < $tamanho; $i++) {
        $linha = [];
        for ($j = 0; $j < $tamanho; $j++) {
            $linha[] = rand(1, 100); // Coeficientes aleatórios
        }
        $linha[] = rand(100, 1000); // Resultado aleatório para o sistema
        $sistema[] = $linha;
    }
    return $sistema;
}

// Função para Resolução de Sistemas Lineares em PHP
function gaussJordan($a) {
    $n = count($a);

    for ($i = 0; $i < $n; $i++) {
        // Verifica se o pivô é zero
        if ($a[$i][$i] == 0) {
            // Tenta encontrar uma linha abaixo com um pivô não zero
            for ($k = $i + 1; $k < $n; $k++) {
                if ($a[$k][$i] != 0) {
                    // Troca as linhas
                    $temp = $a[$i];
                    $a[$i] = $a[$k];
                    $a[$k] = $temp;
                    break;
                }
            }
        }

        // Pivô após troca
        $pivot = $a[$i][$i];

        // Verifica novamente se o pivô é zero
        if ($pivot == 0) {
            throw new Exception("Sistema não possui solução única.");
        }

        for ($j = 0; $j <= $n; $j++) {
            $a[$i][$j] = $a[$i][$j] / $pivot;
        }

        for ($k = 0; $k < $n; $k++) {
            if ($k != $i) {
                $factor = $a[$k][$i];
                for ($j = 0; $j <= $n; $j++) {
                    $a[$k][$j] -= $factor * $a[$i][$j];
                }
            }
        }
    }

    $result = [];
    for ($i = 0; $i < $n; $i++) {
        $result[] = number_format($a[$i][$n]);  // Formata o resultado
    }
    return $result;
}

// Processando o Formulário
$resultadoFibonacci = '';
$resultadoFatorial = '';
$resultadoSoma = '';
$resultadoSistema = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['calcularFibonacci'])) {
        $nFibonacci = (int)$_POST['nFibonacci'];
        $startFibonacci = microtime(true);
        $resultadoFibonacci = calcularFibonacci($nFibonacci);
        $endFibonacci = microtime(true);
        $tempoFibonacci = ($endFibonacci - $startFibonacci) * 1000; // ms
    }

    if (isset($_POST['calcularFatorial'])) {
        $nFatorial = (int)$_POST['nFatorial'];
        $startFatorial = microtime(true);
        $resultadoFatorial = calcularFatorial($nFatorial);
        $endFatorial = microtime(true);
        $tempoFatorial = ($endFatorial - $startFatorial) * 1000; // ms
    }

    if (isset($_POST['calcularSoma'])) {
        $tamanhoMatriz = (int)$_POST['tamanhoMatriz']; // Tamanho da matriz recebido do formulário
        $matrizA = gerarMatrizAleatoria($tamanhoMatriz);
        $matrizB = gerarMatrizAleatoria($tamanhoMatriz);
        
        $startSoma = microtime(true);
        $resultadoSoma = somarMatrizes($matrizA, $matrizB);
        $endSoma = microtime(true);
        $tempoSoma = ($endSoma - $startSoma) * 1000; // ms
    }

    if (isset($_POST['calcularSistema'])) {
        $tamanhoSistema = (int)$_POST['tamanhoSistema'];
        $sistemaLinear = gerarSistemaLinearAleatorio($tamanhoSistema); // Gera o sistema linear aleatório

        $startSistema = microtime(true);
        $resultadoSistema = gaussJordan($sistemaLinear);
        $endSistema = microtime(true);
        $tempoSistema = ($endSistema - $startSistema) * 1000; // ms
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cálculos Matemáticos Avançados</title>
    <link rel="stylesheet" href="style.css"> <!-- Adicionando o CSS -->
</head>
<body>
    <h1>Cálculos Matemáticos Avançados</h1>

    <!-- Cálculo da Série de Fibonacci -->
    <h2>Cálculo da Série de Fibonacci</h2>
    <form method="POST">
        <label for="nFibonacci">Número de elementos:</label>
        <input type="number" name="nFibonacci" id="nFibonacci" value="10" required>
        <button type="submit" name="calcularFibonacci">Calcular</button>
    </form>
    <?php if (isset($resultadoFibonacci)): ?>
        <p>Resultado (Fibonacci): <?php echo $resultadoFibonacci; ?></p>
        <p>Tempo de execução: <?php echo number_format($tempoFibonacci, 5); ?> ms</p>
    <?php endif; ?>

    <!-- Cálculo Fatorial -->
    <h2>Cálculo Fatorial</h2>
    <form method="POST">
        <label for="nFatorial">Número:</label>
        <input type="number" name="nFatorial" id="nFatorial" value="10" required>
        <button type="submit" name="calcularFatorial">Calcular</button>
    </form>
    <?php if (isset($resultadoFatorial)): ?>
        <p>Resultado (Fatorial): <?php echo $resultadoFatorial; ?></p>
        <p>Tempo de execução: <?php echo number_format($tempoFatorial, 5); ?> ms</p>
    <?php endif; ?>

        <!-- Soma de Matrizes -->
        <h2>Soma de Matrizes</h2>
    <form method="POST">
        <label for="tamanhoMatriz">Tamanho da matriz:</label>
        <input type="number" name="tamanhoMatriz" id="tamanhoMatriz" value="3" required>
        <button type="submit" name="calcularSoma">Gerar Matrizes e Somar</button>
    </form>
    <?php if (isset($resultadoSoma)): ?>
        <h3 style="color: white;">Resultado (Soma de Matrizes):</h3>
        <table border="1" cellpadding="10" style="color: white; border-color: white;">
            <?php foreach ($resultadoSoma as $linha): ?>
                <tr>
                    <?php foreach ($linha as $valor): ?>
                        <td style="color: white;"><?php echo $valor; ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </table>
        <p style="color: white;">Tempo de execução: <?php echo number_format($tempoSoma, 5); ?> ms</p>
    <?php endif; ?>

    <!-- Resolução de Sistema Linear (Automático) -->
    <h2>Resolução de Sistema Linear (Método de Gauss-Jordan)</h2>
    <form method="POST">
        <label for="tamanhoSistema">Tamanho do sistema linear:</label>
        <input type="number" name="tamanhoSistema" id="tamanhoSistema" value="3" required>
        <button type="submit" name="calcularSistema">Gerar e Resolver Sistema</button>
    </form>
    <?php if (isset($resultadoSistema)): ?>
        <h3>Resultado (Sistema Linear):</h3>
        <?php foreach ($resultadoSistema as $index => $valor): ?>
            <p>Variável <?php echo chr(88 + $index); ?>: <?php echo $valor; ?></p>
        <?php endforeach; ?>
        <p>Tempo de execução: <?php echo number_format($tempoSistema, 5); ?> ms</p>
    <?php endif; ?>

</body>
</html>
